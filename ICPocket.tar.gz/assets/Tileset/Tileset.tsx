<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="Tileset" tilewidth="16" tileheight="16" tilecount="4096" columns="64">
 <image source="Tileset.png" trans="00bfff" width="1024" height="1024"/>
</tileset>
