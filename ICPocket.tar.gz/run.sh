#!/bin/bash
cd ""
export LD_LIBRARY_PATH=$(pwd)/bin/libs
./bin/main ""
